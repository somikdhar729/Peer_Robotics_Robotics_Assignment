import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image, CameraInfo
from cv_bridge import CvBridge
import cv2
import numpy as np
from ultralytics import YOLO
import torch

class PalletDetectorNode(Node):
    def __init__(self):
        super().__init__('pallet_detector_node')
        
        # Subscribers
        self.image_subscription = self.create_subscription(
            Image,
            '/zed2i/zed_node/rgb/image_rect_color',
            self.image_callback,
            10)
        self.depth_subscription = self.create_subscription(
            Image,
            '/zed2i/zed_node/depth/depth_registered',
            self.depth_callback,
            10)
        self.camera_info_sub = self.create_subscription(
            CameraInfo,
            '/zed2i/zed_node/rgb/camera_info',
            self.camera_info_callback,
            10)
        
        # Publisher
        self.detection_publisher = self.create_publisher(Image, '/pallet_detection/output', 10)
        
        # Initialize CvBridge
        self.bridge = CvBridge()
        
        # Load YOLOv11-seg model
        self.model = YOLO('pallet_detection/models/segment/best.pt')
        self.model.to('cuda')  # Use GPU for inference
        
        # Initialize variables
        self.depth_image = None
        self.camera_info = None

    def camera_info_callback(self, msg):
        self.camera_info = msg

    def depth_callback(self, msg):
        self.depth_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding='passthrough')

    def image_callback(self, msg):
        if self.depth_image is None or self.camera_info is None:
            self.get_logger().warn("Depth image or camera info not available yet")
            return

        # Convert ROS Image message to OpenCV image
        cv_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        
        # Perform inference
        results = self.model(cv_image, size=640)
        
        # Process results
        annotated_image = cv_image.copy()
        for det in results.xyxy[0]:
            x1, y1, x2, y2, conf, cls = det.tolist()
            if conf > 0.5:  # Confidence threshold
                cv2.rectangle(annotated_image, (int(x1), int(y1)), (int(x2), int(y2)), (0, 255, 0), 2)
                
                # Get depth information
                center_x, center_y = int((x1 + x2) / 2), int((y1 + y2) / 2)
                depth = self.depth_image[center_y, center_x]
                
                # Project to 3D space
                fx = self.camera_info.k[0]
                fy = self.camera_info.k[4]
                cx = self.camera_info.k[2]
                cy = self.camera_info.k[5]
                x = (center_x - cx) * depth / fx
                y = (center_y - cy) * depth / fy
                z = depth
                
                cv2.putText(annotated_image, f"Depth: {depth:.2f}m", (int(x1), int(y1)-10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
                cv2.putText(annotated_image, f"3D: ({x:.2f}, {y:.2f}, {z:.2f})", (int(x1), int(y1)-30), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
        
        # Publish annotated image
        output_msg = self.bridge.cv2_to_imgmsg(annotated_image, encoding='bgr8')
        self.detection_publisher.publish(output_msg)

def main(args=None):
    rclpy.init(args=args)
    pallet_detector_node = PalletDetectorNode()
    rclpy.spin(pallet_detector_node)
    pallet_detector_node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()